(function(){
"use strict";
var KEY="secure-vault.v1", ITER=310000;
var $=function(i){return document.getElementById(i)};
var te=new TextEncoder(), td=new TextDecoder();

/* хранение: localStorage, а если недоступен — память */
var mem={};
function sget(k){k=KEY+(k||"");try{return localStorage.getItem(k)}catch(e){return mem[k]||null}}
function sset(v,k){k=KEY+(k||"");try{localStorage.setItem(k,v)}catch(e){mem[k]=v}}
function sdel(){["",".sum"].forEach(function(k){k=KEY+k;try{localStorage.removeItem(k)}catch(e){delete mem[k]}})}

/* крипто: PBKDF2 → AES-GCM 256 */
function b64(u){var s="";for(var i=0;i<u.length;i+=8192)s+=String.fromCharCode.apply(null,u.subarray(i,i+8192));return btoa(s)}
function unb64(s){var b=atob(s),u=new Uint8Array(b.length);for(var i=0;i<b.length;i++)u[i]=b.charCodeAt(i);return u}
async function derive(pw,salt){
  var m=await crypto.subtle.importKey("raw",te.encode(pw),"PBKDF2",false,["deriveKey"]);
  return crypto.subtle.deriveKey({name:"PBKDF2",salt:salt,iterations:ITER,hash:"SHA-256"},m,{name:"AES-GCM",length:256},false,["encrypt","decrypt"]);
}
async function seal(key,salt,text){
  var iv=crypto.getRandomValues(new Uint8Array(12));
  var ct=new Uint8Array(await crypto.subtle.encrypt({name:"AES-GCM",iv:iv},key,te.encode(text)));
  var out=new Uint8Array(28+ct.length);out.set(salt,0);out.set(iv,16);out.set(ct,28);
  return "v2."+b64(out);
}
async function open(pw,blob){
  var ver=blob.slice(0,2);if((ver!=="v1"&&ver!=="v2")||blob.charAt(2)!==".")throw new Error("format");
  var u=unb64(blob.slice(3));
  var salt=u.slice(0,16),iv=u.slice(16,28),ct=u.slice(28);
  var key=await derive(pw,salt);
  var pt=await crypto.subtle.decrypt({name:"AES-GCM",iv:iv},key,ct);
  return {text:td.decode(pt),key:key,salt:salt,ver:ver};
}
async function sha(text){var h=new Uint8Array(await crypto.subtle.digest("SHA-256",te.encode(text)));return Array.prototype.map.call(h,function(x){return x.toString(16).padStart(2,"0")}).join("")}
function same(a,b){if(a.length!==b.length)return false;var d=0;for(var i=0;i<a.length;i++)d|=a.charCodeAt(i)^b.charCodeAt(i);return d===0}
async function encryptText(pw,text){var salt=crypto.getRandomValues(new Uint8Array(16));return seal(await derive(pw,salt),salt,JSON.stringify({t:text,h:await sha(text)}))}

/* состояние */
var S=null; // {key,salt,notes,cur}
var idle=0, tick=null;

function msg(el,t,cls){el.textContent=t;el.className="msg "+(cls||"")}

/* экран блокировки */
function showLock(){
  S=null;clearInterval(tick);
  $("app").hidden=true;$("lock").hidden=false;
  $("pw").value="";$("pw2").value="";
  var has=!!sget();
  $("pw2box").hidden=has;$("wipe").hidden=!has;
  $("unlock").textContent=has?"Открыть":"Создать хранилище";
  $("lockHint").textContent=has?"Введите пароль, чтобы расшифровать данные.":"Придумайте пароль от 8 символов. Восстановить его нельзя: без пароля данные не открыть.";
  $("pw").autocomplete=has?"current-password":"new-password";
  msg($("lockMsg"),"");$("pw").focus();
}
async function unlock(){
  var pw=$("pw").value,has=sget();
  if(!pw){msg($("lockMsg"),"Введите пароль.","err");return}
  $("unlock").disabled=true;msg($("lockMsg"),"Проверяю пароль…");
  try{
    if(has){
      var sum=sget(".sum");
      if(sum&&!same(sum,await sha(has))){msg($("lockMsg"),"Файл хранилища повреждён или изменён: контрольная сумма SHA-256 не совпадает.","err");return}
      var r=await open(pw,has),p=JSON.parse(r.text),legacy=!p.n;
      if(!legacy&&!same(p.h||"",await sha(p.n))){msg($("lockMsg"),"Целостность нарушена: хэш SHA-256 данных не совпадает.","err");return}
      S={key:r.key,salt:r.salt,notes:legacy?(p.notes||[]):JSON.parse(p.n),cur:null};
      if(legacy||!sum)await persist();
    }else{
      if(pw.length<8){msg($("lockMsg"),"Пароль короче 8 символов.","err");return}
      if(pw!==$("pw2").value){msg($("lockMsg"),"Пароли не совпадают.","err");return}
      var salt=crypto.getRandomValues(new Uint8Array(16));
      S={key:await derive(pw,salt),salt:salt,notes:[],cur:null};
      await persist();
    }
    enter();
  }catch(e){msg($("lockMsg"),"Неверный пароль или повреждённые данные.","err")}
  finally{$("unlock").disabled=false}
}
async function persist(){
  for(var i=0;i<S.notes.length;i++){var x=S.notes[i];if(!x.h)x.h=await sha(x.title+"\n"+x.body)}
  var n=JSON.stringify(S.notes),blob=await seal(S.key,S.salt,JSON.stringify({n:n,h:await sha(n)}));
  sset(blob);sset(await sha(blob),".sum");
}
async function verify(){
  var bad=0,i,x;
  for(i=0;i<S.notes.length;i++){x=S.notes[i];if(!same(x.h||"",await sha(x.title+"\n"+x.body)))bad++}
  var blob=sget(),sum=sget(".sum"),ok=!!blob&&!!sum&&same(sum,await sha(blob));
  if(bad||!ok)msg($("noteMsg"),"Проверка не пройдена: "+(bad?"изменённых заметок — "+bad+". ":"")+(ok?"":"контрольная сумма хранилища не совпадает."),"err");
  else msg($("noteMsg"),"Проверено заметок: "+S.notes.length+". Хэши SHA-256 совпадают, данные не изменены.","ok");
}

/* основной экран */
function enter(){
  $("lock").hidden=true;$("app").hidden=false;
  idle=Date.now();clearInterval(tick);
  tick=setInterval(function(){
    var left=300-Math.floor((Date.now()-idle)/1000);
    if(left<=0){showLock();return}
    $("timer").textContent="Автоблокировка через "+Math.floor(left/60)+":"+String(left%60).padStart(2,"0");
  },1000);
  tab(1);renderList();select(null);
}
function tab(n){
  $("p1").hidden=n!==1;$("p2").hidden=n!==2;
  $("t1").setAttribute("aria-selected",n===1);$("t2").setAttribute("aria-selected",n===2);
}
function renderList(){
  var l=$("list");l.textContent="";
  if(!S.notes.length){var p=document.createElement("p");p.className="hint";p.textContent="Пока пусто. Нажмите «Новая заметка».";l.appendChild(p);return}
  S.notes.slice().sort(function(a,b){return b.ts-a.ts}).forEach(function(n){
    var b=document.createElement("button");b.className="item";
    if(n.id===S.cur)b.setAttribute("aria-current","true");
    var t=document.createElement("span");t.textContent=n.title||"Без названия";
    var s=document.createElement("small");s.textContent=new Date(n.ts).toLocaleString("ru-RU");
    b.appendChild(t);b.appendChild(s);
    b.onclick=function(){select(n.id)};l.appendChild(b);
  });
}
function select(id){
  S.cur=id;var n=S.notes.find(function(x){return x.id===id});
  $("title").value=n?n.title:"";$("body").value=n?n.body:"";
  $("del").hidden=!n;$("noteHash").textContent=n&&n.h?"SHA-256: "+n.h:"";msg($("noteMsg"),"");renderList();
}
async function save(){
  var title=$("title").value.trim(),body=$("body").value;
  if(!title&&!body){msg($("noteMsg"),"Добавьте название или текст.","err");return}
  var n=S.notes.find(function(x){return x.id===S.cur});
  if(!n){n={id:String(Date.now())+Math.random().toString(36).slice(2,6)};S.notes.push(n);S.cur=n.id}
  n.title=title;n.body=body;n.ts=Date.now();n.h=await sha(title+"\n"+body);
  try{await persist();$("noteHash").textContent="SHA-256: "+n.h;msg($("noteMsg"),"Сохранено и зашифровано. Хэш записан.","ok")}catch(e){msg($("noteMsg"),"Не удалось сохранить.","err")}
  $("del").hidden=false;renderList();
}
async function del(){
  if(!confirm("Удалить эту заметку?"))return;
  S.notes=S.notes.filter(function(x){return x.id!==S.cur});
  await persist();select(null);
}

/* шифратор */
async function xrun(mode){
  var t=$("xtext").value.trim(),pw=$("xpw").value;
  if(!t||!pw){msg($("xmsg"),"Введите текст и пароль.","err");return}
  msg($("xmsg"),"Работаю…");
  try{
    if(mode==="e"){var h=await sha(t);$("xtext").value=await encryptText(pw,t);$("xhash").textContent="SHA-256 исходного текста: "+h;msg($("xmsg"),"Текст зашифрован, хэш записан внутрь шифра.","ok")}
    else{
      var r=await open(pw,t);
      if(r.ver==="v1"){$("xtext").value=r.text;$("xhash").textContent="";msg($("xmsg"),"Текст расшифрован. Шифр старого формата: хэша SHA-256 в нём нет.","ok");return}
      var p=JSON.parse(r.text);
      if(!p||typeof p.t!=="string")throw new Error("format");
      var h2=await sha(p.t);
      if(!same(p.h||"",h2)){$("xhash").textContent="";msg($("xmsg"),"Целостность нарушена: SHA-256 расшифрованного текста не совпадает с записанным.","err");return}
      $("xtext").value=p.t;$("xhash").textContent="SHA-256: "+h2+" (совпадает)";msg($("xmsg"),"Текст расшифрован, целостность подтверждена.","ok")}
  }catch(e){msg($("xmsg"),mode==="e"?"Не удалось зашифровать.":"Неверный пароль или это не зашифрованный текст.","err")}
}

$("unlock").onclick=unlock;
["pw","pw2"].forEach(function(i){$(i).addEventListener("keydown",function(e){if(e.key==="Enter")unlock()})});
$("wipe").onclick=function(){if(confirm("Все данные будут удалены без возможности восстановления. Продолжить?")){sdel();showLock()}};
$("lockBtn").onclick=showLock;
$("t1").onclick=function(){tab(1)};$("t2").onclick=function(){tab(2)};
$("newNote").onclick=function(){select(null);$("title").focus()};
$("save").onclick=save;$("del").onclick=del;$("verify").onclick=verify;
$("doEnc").onclick=function(){xrun("e")};$("doDec").onclick=function(){xrun("d")};
$("copy").onclick=function(){
  var v=$("xtext").value;if(!v)return;
  (navigator.clipboard?navigator.clipboard.writeText(v):Promise.reject()).then(function(){msg($("xmsg"),"Скопировано.","ok")},function(){$("xtext").select();msg($("xmsg"),"Текст выделен, скопируйте его вручную.")});
};
["keydown","pointerdown"].forEach(function(ev){document.addEventListener(ev,function(){idle=Date.now()})});
if(!window.crypto||!crypto.subtle){msg($("lockMsg"),"Браузер не поддерживает шифрование Web Crypto.","err");$("unlock").disabled=true}
else showLock();
})();
